package com.iyul.macro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

/** Satu aksi sentuh. Koordinat disimpan sebagai persen layar (0..1). */
class Stroke(
    val delay: Long, // jeda sejak aksi sebelumnya selesai (ms)
    val x1: Float, val y1: Float,
    val x2: Float, val y2: Float,
    val dur: Long    // lama sentuhan (ms)
)

class MacroService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var recView: View? = null
    private var recLp: WindowManager.LayoutParams? = null
    private var status: TextView? = null
    private var recBtn: Button? = null
    private var loopBtn: Button? = null

    private val strokes = mutableListOf<Stroke>()
    private var playing = false
    private var recording = false
    private var idx = 0
    private var done = 0
    private val loopOptions = intArrayOf(0, 5, 10, 25, 50, 100) // 0 = tanpa batas
    private var loopSel = 0

    private var downT = 0L
    private var lastEnd = 0L
    private var sx = 0f
    private var sy = 0f

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        load()
        buildPanel()
        setStatus("Siap (${strokes.size} aksi)")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAll() }

    override fun onDestroy() {
        stopAll()
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        textSize = 11f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(20, 10, 20, 10)
        setOnClickListener { f() }
    }

    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(210, 20, 20, 20))
            setPadding(8, 8, 8, 8)
        }
        val header = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(8, 4, 8, 8)
        }
        status = header
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        recBtn = btn("REC") { toggleRec() }
        loopBtn = btn("Loop: ∞") { cycleLoop() }
        row.addView(recBtn)
        row.addView(btn("PLAY") { play() })
        row.addView(btn("STOP") { stopAll() })
        row.addView(loopBtn)
        p.addView(header)
        p.addView(row)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 20 }

        var ox = 0; var oy = 0; var tx = 0f; var ty = 0f
        header.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { ox = lp.x; oy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - tx).toInt()
                    lp.y = oy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(p, lp)
                }
            }
            true
        }
        panel = p
        panelLp = lp
        wm.addView(p, lp)
    }

    private fun setStatus(s: String) { status?.text = "≡ $s" }

    private fun cycleLoop() {
        loopSel = (loopSel + 1) % loopOptions.size
        val n = loopOptions[loopSel]
        loopBtn?.text = "Loop: " + (if (n == 0) "∞" else n.toString())
    }

    // ---------- Rekam ----------

    private val recTouch = View.OnTouchListener { _, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downT = e.eventTime; sx = e.rawX; sy = e.rawY }
            MotionEvent.ACTION_UP -> {
                val (w, h) = screen()
                val s = Stroke(
                    if (strokes.isEmpty()) 0L else downT - lastEnd,
                    sx / w, sy / h, e.rawX / w, e.rawY / h,
                    max(40L, e.eventTime - downT)
                )
                lastEnd = e.eventTime
                strokes.add(s)
                setStatus("Rekam: ${strokes.size} aksi")
                // Teruskan sentuhan ke game: overlay dibuat tembus dulu selama gesture jalan.
                setRecTouchable(false)
                dispatch(s) { setRecTouchable(true) }
            }
        }
        true
    }

    private fun setRecTouchable(on: Boolean) {
        val v = recView ?: return
        val lp = recLp ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    private fun toggleRec() {
        if (playing) return
        if (!recording) startRec() else stopRec()
    }

    private fun startRec() {
        strokes.clear(); lastEnd = 0L; recording = true
        val v = View(this).apply {
            setBackgroundColor(Color.argb(40, 255, 0, 0))
            setOnTouchListener(recTouch)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        recView = v; recLp = lp
        wm.addView(v, lp)
        // panel dipasang ulang supaya tetap di atas layer rekam
        panel?.let { wm.removeView(it); wm.addView(it, panelLp) }
        recBtn?.text = "SIMPAN"
        setStatus("Merekam… main seperti biasa")
    }

    private fun stopRec() {
        recording = false
        recView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        recView = null; recLp = null
        recBtn?.text = "REC"
        save()
        setStatus("Tersimpan (${strokes.size} aksi)")
    }

    // ---------- Putar ----------

    private fun play() {
        if (recording) stopRec()
        if (strokes.isEmpty()) { setStatus("Belum ada rekaman"); return }
        if (playing) return
        playing = true; idx = 0; done = 0
        setStatus("Main… loop 0")
        playNext()
    }

    private fun playNext() {
        if (!playing) return
        if (idx >= strokes.size) {
            done++
            val max = loopOptions[loopSel]
            if (max > 0 && done >= max) { stopAll(); return }
            idx = 0
            setStatus("Main… loop $done")
            handler.postDelayed({ playNext() }, 800)
            return
        }
        val s = strokes[idx]
        val wait = if (idx == 0) 0L else max(0L, s.delay + Random.nextLong(-40L, 41L))
        handler.postDelayed({
            if (!playing) return@postDelayed
            dispatch(s) { idx++; playNext() }
        }, wait)
    }

    private fun stopAll() {
        playing = false
        handler.removeCallbacksAndMessages(null)
        if (recording) stopRec()
        if (panel != null) setStatus("Berhenti (loop $done)")
    }

    // ---------- Gesture ----------

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Float, Float> {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels.toFloat(), m.heightPixels.toFloat())
    }

    private fun dispatch(s: Stroke, onDone: (() -> Unit)?) {
        val (w, h) = screen()
        val path = Path().apply {
            moveTo(s.x1 * w, s.y1 * h)
            if (abs(s.x2 - s.x1) * w > 4f || abs(s.y2 - s.y1) * h > 4f) lineTo(s.x2 * w, s.y2 * h)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, s.dur.coerceIn(1L, 30000L)))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { onDone?.invoke() }
            override fun onCancelled(d: GestureDescription?) { onDone?.invoke() }
        }, null)
        if (!ok) onDone?.invoke()
    }

    // ---------- Simpan / muat ----------

    private fun save() {
        val str = strokes.joinToString(";") { "${it.delay},${it.x1},${it.y1},${it.x2},${it.y2},${it.dur}" }
        getSharedPreferences("macro", MODE_PRIVATE).edit().putString("s", str).apply()
    }

    private fun load() {
        strokes.clear()
        val str = getSharedPreferences("macro", MODE_PRIVATE).getString("s", "") ?: ""
        if (str.isBlank()) return
        for (part in str.split(";")) {
            val f = part.split(",")
            if (f.size == 6) {
                strokes.add(Stroke(f[0].toLong(), f[1].toFloat(), f[2].toFloat(),
                    f[3].toFloat(), f[4].toFloat(), f[5].toLong()))
            }
        }
    }
}
