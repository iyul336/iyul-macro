package com.iyul.macro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/** Titik di layar. Posisi disimpan sebagai persen layar (0..1). */
class Marker(var x: Float, var y: Float)

/** Satu penekanan: titik ke-m, mulai pada [start] ms sejak awal siklus, ditahan [dur] ms. */
class Ev(val m: Int, val start: Long, val dur: Long)

class MacroService : AccessibilityService() {

    private enum class Mode { EDIT, REC, PLAY }

    private val maxStrokes = 10
    private val maxGestureMs = 60000L

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var sizePx = 120

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var status: TextView? = null
    private var recBtn: Button? = null
    private var loopBtn: Button? = null

    private val markers = mutableListOf<Marker>()
    private val views = mutableListOf<TextView>()
    private val lps = mutableListOf<WindowManager.LayoutParams>()
    private val events = mutableListOf<Ev>()
    private var cycleLen = 0L

    private var mode = Mode.EDIT
    private var recStart = -1L
    private val downAt = HashMap<Int, Long>()

    private var playing = false
    private var done = 0
    private val loopOptions = intArrayOf(0, 5, 10, 25, 50, 100) // 0 = tanpa batas
    private var loopSel = 0

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        sizePx = (48 * resources.displayMetrics.density).toInt()
        load()
        buildPanel()
        for (i in markers.indices) addMarkerView(i)
        bringPanelFront()
        setStatus("Siap: ${markers.size} titik, ${events.size} aksi")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAll() }

    override fun onDestroy() {
        stopAll()
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        for (v in views) { try { wm.removeView(v) } catch (_: Exception) {} }
        super.onDestroy()
    }

    // ---------- Util ----------

    private fun overlayLp(w: Int, h: Int, extraFlags: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                extraFlags,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Float, Float> {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels.toFloat(), m.heightPixels.toFloat())
    }

    private fun setStatus(s: String) { status?.text = "≡ $s" }

    // ---------- Panel ----------

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        textSize = 11f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(20, 10, 20, 10)
        setOnClickListener { f() }
    }

    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(210, 20, 20, 20))
            setPadding(8, 8, 8, 8)
        }
        val header = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(8, 4, 8, 8)
        }
        status = header
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        recBtn = btn("REC") { toggleRec() }
        loopBtn = btn("Loop: ∞") { cycleLoop() }
        row1.addView(btn("+Titik") { addMarker() })
        row1.addView(btn("-Titik") { removeMarker() })
        row1.addView(recBtn)
        row2.addView(btn("PLAY") { play() })
        row2.addView(btn("STOP") { stopAll() })
        row2.addView(loopBtn)
        p.addView(header)
        p.addView(row1)
        p.addView(row2)

        val lp = overlayLp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0)
        lp.x = 20; lp.y = 20

        var ox = 0; var oy = 0; var tx = 0f; var ty = 0f
        header.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { ox = lp.x; oy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - tx).toInt()
                    lp.y = oy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(p, lp)
                }
            }
            true
        }
        panel = p
        panelLp = lp
        wm.addView(p, lp)
    }

    private fun bringPanelFront() {
        val p = panel ?: return
        try { wm.removeView(p) } catch (_: Exception) {}
        wm.addView(p, panelLp)
    }

    private fun cycleLoop() {
        loopSel = (loopSel + 1) % loopOptions.size
        val n = loopOptions[loopSel]
        loopBtn?.text = "Loop: " + (if (n == 0) "∞" else n.toString())
    }

    // ---------- Titik ----------

    @Suppress("DEPRECATION")
    private fun addMarkerView(i: Int) {
        val m = markers[i]
        val (w, h) = screen()
        val tv = TextView(this).apply {
            text = (i + 1).toString()
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(120, 255, 60, 60))
                setStroke(3, Color.WHITE)
            }
        }
        val lp = overlayLp(sizePx, sizePx, WindowManager.LayoutParams.FLAG_SPLIT_TOUCH)
        lp.x = (m.x * w - sizePx / 2f).toInt()
        lp.y = (m.y * h - sizePx / 2f).toInt()

        var ox = 0; var oy = 0; var tx = 0f; var ty = 0f
        tv.setOnTouchListener { _, e ->
            when (mode) {
                Mode.EDIT -> when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { ox = lp.x; oy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - tx).toInt()
                        lp.y = oy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(tv, lp)
                    }
                    MotionEvent.ACTION_UP -> {
                        val (sw, sh) = screen()
                        m.x = (lp.x + sizePx / 2f) / sw
                        m.y = (lp.y + sizePx / 2f) / sh
                        save()
                    }
                }
                Mode.REC -> when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        val now = SystemClock.uptimeMillis()
                        if (recStart < 0) recStart = now
                        downAt[i] = now
                        tv.alpha = 0.5f
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        tv.alpha = 1f
                        val t0 = downAt.remove(i)
                        if (t0 != null) {
                            val now = SystemClock.uptimeMillis()
                            events.add(Ev(i, t0 - recStart, max(50L, now - t0)))
                            setStatus("Rekam: ${events.size} aksi")
                        }
                    }
                }
                else -> {}
            }
            true
        }
        views.add(tv)
        lps.add(lp)
        wm.addView(tv, lp)
    }

    private fun addMarker() {
        if (mode != Mode.EDIT) return
        if (markers.size >= maxStrokes) { setStatus("Maksimal $maxStrokes titik"); return }
        markers.add(Marker(0.35f + 0.06f * markers.size, 0.5f))
        addMarkerView(markers.size - 1)
        bringPanelFront()
        save()
        setStatus("Titik ${markers.size}: geser ke tombol game")
    }

    private fun removeMarker() {
        if (mode != Mode.EDIT || markers.isEmpty()) return
        val i = markers.size - 1
        try { wm.removeView(views[i]) } catch (_: Exception) {}
        views.removeAt(i); lps.removeAt(i); markers.removeAt(i)
        events.removeAll { it.m == i }
        save()
        setStatus("${markers.size} titik")
    }

    private fun applyMode() {
        for (i in views.indices) {
            val lp = lps[i]
            lp.flags = if (mode == Mode.PLAY)
                lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            else
                lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            views[i].alpha = if (mode == Mode.PLAY) 0.15f else 1f
            try { wm.updateViewLayout(views[i], lp) } catch (_: Exception) {}
        }
    }

    // ---------- Rekam ----------

    private fun toggleRec() {
        if (playing) return
        if (mode != Mode.REC) {
            if (markers.isEmpty()) { setStatus("Tambah titik dulu (+Titik)"); return }
            events.clear(); recStart = -1L; downAt.clear()
            mode = Mode.REC
            applyMode()
            recBtn?.text = "SIMPAN"
            setStatus("Rekam: tekan titik sesuai urutan")
        } else {
            val now = SystemClock.uptimeMillis()
            cycleLen = if (recStart < 0) 0L else now - recStart
            mode = Mode.EDIT
            applyMode()
            recBtn?.text = "REC"
            save()
            setStatus("Tersimpan: ${events.size} aksi, ${cycleLen / 1000}s")
        }
    }

    // ---------- Putar ----------

    private fun play() {
        if (mode == Mode.REC) toggleRec()
        if (events.isEmpty() || cycleLen <= 0L) { setStatus("Belum ada rekaman"); return }
        if (playing) return
        playing = true
        done = 0
        mode = Mode.PLAY
        applyMode()
        setStatus("Main… loop 0")
        scheduleCycle(SystemClock.uptimeMillis() + 500L)
    }

    private fun scheduleCycle(startAt: Long) {
        if (!playing) return
        val sorted = events.sortedBy { it.start }
        val groups = mutableListOf<MutableList<Ev>>()
        var curEnd = -1L
        for (ev in sorted) {
            if (groups.isNotEmpty() && ev.start < curEnd + 30L) {
                groups.last().add(ev)
                curEnd = max(curEnd, ev.start + ev.dur)
            } else {
                groups.add(mutableListOf(ev))
                curEnd = ev.start + ev.dur
            }
        }
        for (g in groups) {
            val gs = g[0].start
            val wait = max(0L, startAt + gs - SystemClock.uptimeMillis())
            handler.postDelayed({ fire(g, gs) }, wait)
        }
        val endWait = max(0L, startAt + cycleLen - SystemClock.uptimeMillis())
        handler.postDelayed({
            done++
            val limit = loopOptions[loopSel]
            if (limit > 0 && done >= limit) {
                stopAll()
            } else {
                setStatus("Main… loop $done")
                scheduleCycle(startAt + cycleLen + 300L)
            }
        }, endWait)
    }

    /** Semua penekanan yang waktunya bertumpuk dikirim sebagai satu gesture multi-jari. */
    private fun fire(g: List<Ev>, gs: Long) {
        if (!playing) return
        val (w, h) = screen()
        val b = GestureDescription.Builder()
        var n = 0
        for (ev in g) {
            if (n >= maxStrokes) break
            val mk = markers.getOrNull(ev.m) ?: continue
            val path = Path().apply {
                moveTo(mk.x * w, mk.y * h)
                if (ev.dur > 250L) lineTo(mk.x * w + 1f, mk.y * h)
            }
            val dur = ev.dur.coerceIn(1L, maxGestureMs)
            b.addStroke(GestureDescription.StrokeDescription(path, ev.start - gs, dur))
            n++
        }
        if (n == 0) return
        if (g.size > maxStrokes) setStatus("Terlalu banyak tekanan serentak (maks $maxStrokes)")
        try {
            dispatchGesture(b.build(), null, null)
        } catch (e: Exception) {
            setStatus("Gagal kirim gesture: ${e.message}")
        }
    }

    private fun stopAll() {
        playing = false
        handler.removeCallbacksAndMessages(null)
        if (mode == Mode.REC) {
            toggleRec()
        } else if (mode == Mode.PLAY) {
            mode = Mode.EDIT
            applyMode()
        }
        if (panel != null) setStatus("Berhenti (loop $done)")
    }

    // ---------- Simpan / muat ----------

    private fun save() {
        getSharedPreferences("macro2", MODE_PRIVATE).edit()
            .putString("m", markers.joinToString(";") { "${it.x},${it.y}" })
            .putString("e", events.joinToString(";") { "${it.m},${it.start},${it.dur}" })
            .putLong("len", cycleLen)
            .apply()
    }

    private fun load() {
        markers.clear(); events.clear()
        val sp = getSharedPreferences("macro2", MODE_PRIVATE)
        for (part in (sp.getString("m", "") ?: "").split(";")) {
            val f = part.split(",")
            if (f.size == 2) markers.add(Marker(f[0].toFloat(), f[1].toFloat()))
        }
        for (part in (sp.getString("e", "") ?: "").split(";")) {
            val f = part.split(",")
            if (f.size == 3) events.add(Ev(f[0].toInt(), f[1].toLong(), f[2].toLong()))
        }
        cycleLen = sp.getLong("len", 0L)
    }
}
