package com.iyul.macro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "iyul Macro v2\n\n" +
                "1. Aktifkan \"iyul Macro\" di pengaturan Aksesibilitas (tombol di bawah).\n" +
                "2. Buka game. Panel kecil muncul (geser lewat tulisan di atasnya).\n" +
                "3. Tap +Titik, lalu geser lingkaran bernomor ke atas tombol game (blok, serang, joystick, Fight, dll). Maks 10 titik.\n" +
                "4. Tap REC, lalu tekan titik-titik itu sesuai urutan dan lama tahan yang kamu mau. Boleh beberapa jari sekaligus. Game tidak merespons saat REC, jadi tunggu sendiri sesuai durasi aslinya (misal loading).\n" +
                "5. Tap SIMPAN, atur Loop, lalu PLAY. STOP untuk berhenti."
        })
        root.addView(Button(this).apply {
            text = "Buka pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(root)
    }
}
