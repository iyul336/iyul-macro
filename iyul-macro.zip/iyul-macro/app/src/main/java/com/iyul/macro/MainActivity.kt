package com.iyul.macro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "iyul Macro\n\n" +
                "1. Tekan tombol di bawah, cari \"iyul Macro\", lalu aktifkan.\n" +
                "2. Buka game. Panel kecil muncul di layar (geser lewat tulisan di atasnya).\n" +
                "3. REC: lakukan satu siklus penuh (Fight -> bertarung -> klaim -> balik ke Fight). Tekan SIMPAN kalau selesai.\n" +
                "4. Atur Loop, lalu PLAY. STOP untuk berhenti."
        })
        root.addView(Button(this).apply {
            text = "Buka pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(root)
    }
}
